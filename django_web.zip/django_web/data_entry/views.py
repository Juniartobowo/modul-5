from django.shortcuts import render, get_object_or_404, redirect
from .forms import PenggunaForm, ContentForm
from .models import Pengguna
from django.db.models import Q

def set_pengguna(request):
    list_pengguna = Pengguna.objects.all().order_by('-id')
    context = None
    form = PenggunaForm(None)
    email_p = None
    if request.method == "POST":
        form = PenggunaForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            request.session['email'] = email
            request.session.modified = True
            form.save()
            list_pengguna = Pengguna.objects.all().order_by('-id')
            email_p = request.session['email']
            context = {
                'form': form,
                'list_pengguna': list_pengguna,
                'email_p': email_p,
            }
            return render(request, 'data_entry/input_data_1.html', context)
    else:
        context = {
            'form': form,
            'list_pengguna': list_pengguna,
        }
    return render(request, 'data_entry/input_data_1.html', context)


def set_content(request):
    form = ContentForm(None)
    if request.method == 'POST':
        form = ContentForm(request.POST)
        if form.is_valid():
            form.save()
            context = {
                'form': form,
            }
            return render(request, 'data_entry/create_content.html', context)
    else:
        context = {
            'form': form,
        }
    return render(request, 'data_entry/create_content.html', context)



def view_pengguna(request, pk):
    pengguna = get_object_or_404(Pengguna, pk=pk)
    return render(request, 'data_entry/pengguna_detail.html', {
        'pengguna': pengguna
    })


def update_pengguna(request, pk):
    pengguna = get_object_or_404(Pengguna, pk=pk)
    if request.method == "POST":
        form = PenggunaForm(request.POST, instance=pengguna)
        if form.is_valid():
            form.save()
            return redirect('data_entry:view_pengguna', pk=pk)
    else:
        form = PenggunaForm(instance=pengguna)

    return render(request, 'data_entry/update_pengguna.html', {
        'form': form,
        'pengguna': pengguna
    })


def delete_pengguna(request, pk):
    pengguna = get_object_or_404(Pengguna, pk=pk)
    pengguna.delete()
    return redirect('data_entry:set_pengguna')


def search_pengguna_by_state(request):
    query = request.GET.get('state', '')
    results = Pengguna.objects.filter(state__icontains=query)
    return render(request, 'data_entry/search_results.html', {
        'results': results,
        'query': query
    })
