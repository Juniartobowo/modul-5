from django import forms
from .models import Pengguna, Content  # pastikan model Content juga sudah ada

class PenggunaForm(forms.ModelForm):
    class Meta:
        model = Pengguna
        fields = '__all__'

class ContentForm(forms.ModelForm):
    class Meta:
        model = Content
        fields = ['author', 'artikel', 'set_view']
        widgets = {
            'artikel': forms.Textarea(attrs={'cols': 80, 'rows': 10}),  # Atur ukuran
        }
