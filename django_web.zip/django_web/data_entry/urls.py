from django.urls import path
from . import views

app_name = 'data_entry'

urlpatterns = [
    path('', views.set_pengguna, name='set_pengguna'),
    path('view/<int:pk>/', views.view_pengguna, name='view_pengguna'),
    path('edit/<int:pk>/', views.update_pengguna, name='update_pengguna'),
    path('delete/<int:pk>/', views.delete_pengguna, name='delete_pengguna'),
    path('content/', views.set_content, name='set_content'),
    path('search/', views.search_pengguna_by_state, name='search_pengguna_by_state'),
]
